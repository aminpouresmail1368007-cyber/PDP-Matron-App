PDP مترون آنلاین V3 - سورس Android آماده GitHub Actions

قابلیت‌های UI: ورود اختصاصی هر پرستار، PDP، آزمون آنلاین، نظرسنجی، داشبورد نقش‌محور.
این APK برای کار چندگوشی باید به Backend مرکزی V3 متصل شود؛ آدرس سرور در اولین صفحه برنامه ثبت می‌شود.

ساخت APK: کل محتویات این پوشه را در ریشه Repository قرار دهید، سپس Actions > Build PDP Matron Android APK > Run workflow.
